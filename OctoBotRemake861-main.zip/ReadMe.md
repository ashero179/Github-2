# OCTOBOT REMAKE

A simple Faceb••k bot project for us all nigga 😌 this project is a remake from the original src of yafbv3.2 

## Installation

Install this shit
```bash
npm install
```
to Run ts
```bash 
node index.js
```

## IMPORTANT
GO TO yafb_conf.json 
to login the key 🥴

## SOME SHITS HERE @ config.json
u can edit/add configuration there including prefix, port and admin😗 as well as password of dashboard 
 
 ## ADMIN BOT 
 can be added using botadmin command 
 
## index.html ??
- if i where u don't share this shit

## how to upload using WebView (HTML)
lagay mo ang appstate sa cookie.json bago mo iuupload sa  website mo

## for Security 
i added WEBVIEW on Config json pRa yun only sa WebView lang maacess yung api
## PM MOKO SAKALING MAY TANONG KA
	 https://fb.com/yetanotherfbbot

## Join us.
[Join the chat](https://m.me/j/AbY7Ldz4LsCvTQcK/)

